## Misión dos Fundamentos de Programación para IA




### Unidad 1: Repaso de conceptos de programación

<a href="https://www.canva.com/design/DAGEl2pQeQg/QoNwBNFiGP3J5z3sZaVeHg/view?utm_content=DAGEl2pQeQg&utm_campaign=designshare&utm_medium=link&utm_source=editor" target="_blank">Enlace a Presentación Python en IA</a>

## [📄 ](./01_FundamentosPython.ipynb/) Script clase Variables en python, Contenedores python
## [📄 ](./02_Condiciones.ipynb/) Script clase clase Ciclos, Funciones, Manejo de errores y excepciones



Alternatively try them directly on **Google Colab** 

| Title | Tutorial Notebook  | Solution |
|-|:-:|:-:|
|  Ejemplos y Actividad 2 | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/xXThanatosXx/Curso-IA-G3/blob/main/Misi%C3%B3n%20Uno/Unidad%203/EjemplosPython.ipynb)  |
