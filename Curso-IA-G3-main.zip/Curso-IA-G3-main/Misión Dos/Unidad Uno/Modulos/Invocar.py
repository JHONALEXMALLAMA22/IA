from mimodulo import saludar

mensaje = saludar("Juan")
print(mensaje)  # Salida: Hola, Juan!
