def saludar(nombre):
    return f"Hola, {nombre}!"
