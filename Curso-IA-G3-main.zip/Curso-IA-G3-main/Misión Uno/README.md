## Misión uno presentaciones y enlaces a Scripts

### Unidad uno
<a href="https://www.canva.com/design/DAGCm11QmDg/VrkxolLa43YfMZ4IXfF3CA/edit?utm_content=DAGCm11QmDg&utm_campaign=designshare&utm_medium=link2&utm_source=sharebutton" target="_blank">Enlace a Presentación Introducción a IA</a>

### Unidad dos

<a href="https://www.canva.com/design/DAGCnBi8IDU/TkQgC_cxDYC5TfJoGiBQxw/view?utm_content=DAGCnBi8IDU&utm_campaign=designshare&utm_medium=link&utm_source=editor" target="_blank">Enlace a Presentación Tareas, Modelos y Evaluacion en IA</a>

### Unidad Tres


Alternatively try them directly on **Google Colab** 

| Title | Tutorial Notebook  | Solution |
|-|:-:|:-:|
| Algebra Lineal  | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/xXThanatosXx/Curso-IA-G3/blob/main/Misi%C3%B3n%20Uno/Unidad%203/Algebra%20lineal.ipynb) 
|  Probabilidad | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/mml-book/mml-book.github.io/blob/master/tutorials/tutorial_pca.ipynb)  |
|  Actividad | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/xXThanatosXx/Curso-IA-G3/blob/main/Misi%C3%B3n%20Uno/Unidad%203/Actividad.ipynb)  |

