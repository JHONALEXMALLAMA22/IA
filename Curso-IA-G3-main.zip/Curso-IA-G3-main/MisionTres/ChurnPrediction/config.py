


DATA_PATH = 'D:\Shadow\GitHub\Curso-IA-G3\Misión Dos\ChurnPrediction\churn_data.xlsx'
